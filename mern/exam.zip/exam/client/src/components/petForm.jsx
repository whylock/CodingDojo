import React from 'react'

const PetForm = props => {
    const { input, errors, handleInputChange, handleFormSubmit, submitValue } = props
    return (
        <form className='col-5 mx-auto bg-light rounded' onSubmit={handleFormSubmit}>
            <div className="form-group">
                <label htmlFor="name">Name</label>
                <input id="name" className="form-control" value={input.name} onChange={handleInputChange} type="text" name="name" />
                <span className='text-danger'>{errors.name ? errors.name.message : ""}</span>
            </div>
            <div className="form-group">
                <label htmlFor="type">Type</label>
                <input id="type" className="form-control" value={input.type} onChange={handleInputChange}  type="text" name="type" />
                <span className='text-danger'>{errors.type ? errors.type.message : ""}</span>
            </div>
            <div className="form-group">
                <label htmlFor="desc">Description</label>
                <input id="desc" className="form-control" value={input.desc} onChange={handleInputChange}  type="text" name="desc" />
                <span className='text-danger'>{errors.desc ? errors.desc.message : ""}</span>
            </div>
            <div className="form-group">
                <label htmlFor="skillOne">Skill One</label>
                <input id="skillOne" className="form-control" value={input.skillOne} onChange={handleInputChange}  type="text" name="skillOne" />
                <span className='text-danger'>{errors.skillOne ? errors.skillOne.message : ""}</span>
            </div>
            <div className="form-group">
                <label htmlFor="skillTwo">Skill Two</label>
                <input id="skillTwo" className="form-control" value={input.skillTwo} onChange={handleInputChange}  type="text" name="skillTwo"/>
            </div>
            <div className="form-group">
                <label htmlFor="skillThree">Skill Three</label>
                <input id="skillThree" className="form-control" value={input.skillThree} onChange={handleInputChange}  type="text" name="skillThree"/>
            </div>
            <input type="submit" value={submitValue} className='btn btn-primary'/>
        </form>
    )
}

export default PetForm
