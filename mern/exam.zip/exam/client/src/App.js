import React from "react";
import Dashboard from "./views/Main";
import AddPet from "./views/New";
import Show from "./views/Show"
import Edit from "./views/Edit"
import { Router } from "@reach/router";

function App() {
	return (
		<div>
			<Router>
				<Dashboard path={"/"}></Dashboard>
        <AddPet path={"/pet/new"}></AddPet>
        <Show path={'/pet/:id'}></Show>
        <Edit path={'update/pet/:id'}></Edit>
			</Router>
		</div>
	);
}

export default App;
