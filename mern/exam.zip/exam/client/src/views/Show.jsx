import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { navigate, Link } from '@reach/router';

const PetDetails = (props) => {
    const initialPet = {
        name: "",
        type: "",
        desc: "",
        skillOne: "",
        skillTwo: "",
        skillThree: "",
    }
    const [pet, setPet] = useState(initialPet)
    const [likes, setLikes] = useState(0);

    useEffect(() => {
        axios.get(`http://localhost:8000/api/pet/${props.id}`)
            .then(res => {
                setPet(res.data.results)
                console.log(res);
            })
            .catch(err => console.log(err));
    }, [props]);

    const deletePet = (e) => {
        e.preventDefault();
        axios.delete(`http://localhost:8000/api/destory/pet/${pet._id}`)
            .then(res => {
                    navigate("/");
                })
            .catch(err => console.log(err));
    }

    return (
        <div>
            <div className="col-2">
				<Link to={`/`}>back to home</Link>
			</div>
            <div className="form-group m-2 p-2 bg-dark rounded shadow-lg text-dark">
                <div>
                    <p className="text-light text-left mt-2 ml-2">Name: {pet.name}</p>
                    <p className="text-light text-left mt-2 ml-2">Type: {pet.type}</p>
                    <p className="text-light text-left mt-2 ml-2">Description: {pet.desc}</p>
                    <p className="text-light text-left mt-2 ml-2">Skills: {pet.skillOne} | {pet.skillTwo} | {pet.skillThree}  </p>
                    <p className="text-light text-left mt-2 ml-2">Likes: {likes}</p>
                    <button className="btn btn-primary m-1 text-dark" onClick={deletePet} value={pet.name}>Adopt</button>
                    <button className="btn btn-warning m-1 text-dark" onClick={(e) => setLikes(likes + 1)}>Like</button>
                </div>
            </div>
        </div>
    );
};
export default PetDetails
