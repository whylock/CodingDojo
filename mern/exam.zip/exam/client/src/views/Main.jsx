import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "@reach/router";
import "bootstrap/dist/css/bootstrap.min.css";

const Dashboard = (props) => {
	const [pets, setPets] = useState([]);
	useEffect(() => {
		axios
			.get("http://localhost:8000/api/pet")
			.then((res) => {
				console.log(res.data);
				setPets(res.data.results);
			})
			.catch((err) => console.log(err));
	}, []);

	return (
		<div className="d-flex container justify-content-between col-12">
			<div className="col-2">
				<Link to={`/pet/new`}>Add a new Pet</Link>
			</div>
			<table className="table col-6 table-dark">
				<thead className="thead-dark">
					<tr>
						<th>Name</th>
						<th>Type</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
					{pets.map((pet, i) => {
						return (
							<tr key={i}>
								<td>{pet.name}</td>
								<td>{pet.type}</td>
								<td>
									<Link to={`/pet/${pet._id}`}>Details</Link>|<Link to={`/update/pet/${pet._id}`}>Edit</Link>
								</td>
							</tr>
						);
					})}
				</tbody>
			</table>
		</div>
	);
};

export default Dashboard;
