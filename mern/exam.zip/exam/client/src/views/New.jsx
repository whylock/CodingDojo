import React, { useState } from "react";
import PetForm from "../components/petForm";
import axios from 'axios'
import { navigate, Link } from '@reach/router'

const AddPet = (props) => {
    const initialPet = {
        name: "",
        type: "",
        desc: "",
        skillOne: "",
        skillTwo: ""
    }

    const [pet, setPet] = useState(initialPet)
    const [errors, setErrors] = useState(initialPet)

    const onFormChange = (e) => {
        setPet({
            ...pet,
            [e.target.name]:e.target.value
        })
    }
    
    const onFormSubmit = (e) => {
        setErrors(initialPet)
        e.preventDefault();
        axios.post('http://localhost:8000/api/create/pet', pet)
            .then(res => {
                if(res.data.results){
                    navigate('/')
                }
                else {
                    setErrors(res.data)
                }
            })
        .catch(err => console.log(err))
    }
    

	return (
        <div>
            <div className="col-2">
				<Link to={`/`}>back to home</Link>
			</div>
            <PetForm
                input={pet}
                errors={errors}
                handleInputChange={onFormChange}
                handleFormSubmit={onFormSubmit}
                submitValue="Add A Pet"> 
            </PetForm>
		</div>
	);
};

export default AddPet;
