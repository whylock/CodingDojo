import React, { useState, useEffect } from "react";
import axios from "axios";
import { navigate, Link } from "@reach/router";
import PetForm from "../components/petForm";

const Edit = (props) => {
	const initialPet = {
		name: "",
		type: "",
		desc: "",
		skillOne: "",
		skillTwo: "",
	};

	const [edit, setEdit] = useState(initialPet);
	const [errors, setErrors] = useState(initialPet);

	useEffect(() => {
		axios
			.get(`http://localhost:8000/api/pet/${props.id}`, edit)
			.then((res) => setEdit(res.data.results))
			.catch((err) => console.log(err));
	}, [props]);

	const onFormChange = (e) => {
		setEdit({
			...edit,
			[e.target.name]: e.target.value,
		});
	};
	const onFormSubmit = (e) => {
		setErrors(initialPet);
		e.preventDefault();
		axios
			.put(`http://localhost:8000/api/update/pet/${props.id}`, edit)
			.then((res) => {
				if (res.data.results) {
					navigate("/");
				} else {
					setErrors(res.data);
				}
			})
			.catch((err) => console.log(err));
	};
	return (
		<div>
			<div className="col-2">
				<Link to={`/`}>back to home</Link>
			</div>
			<PetForm input={edit} errors={errors} handleInputChange={onFormChange} handleFormSubmit={onFormSubmit} submitValue="Edit This Pet"></PetForm>
		</div>
	);
};

export default Edit;
