const express = require("express");
const { Mongoose } = require("mongoose");
const pet = require("../models/pet.model");



module.exports = {

    index: (req, res) => {
        pet.find().sort({ type: 'asc'})
            .then(data => res.json({results:data }))
            .catch(err => res.json(err.errors))
    },
    create: (req, res) => {
        pet.create(req.body)
            .then(data => res.json({ results: data }))
            .catch(err => res.json(err.errors))
    },
    showOne: (req, res) => {
        pet.findOne({_id:req.params.id})
            .then(data => res.json({ results: data }))
            .catch(err => res.json(err.errors))
    },
    updateOne: (req, res) => {
        pet.findOneAndUpdate({_id:req.params.id},req.body, {runValidators:true, context: 'query', new:true,useFindAndModify:false})
            .then(data => res.json({results: data}))
            .catch(err => res.json(err.errors))
    },
    // random: (req, res) => {
    //     pet.find()
    //         .then(data => {
    //             let rand = Math.floor(Math.random() * data.length)
    //             res.json({ results: data[rand] });
    //         })
    //         .catch(err => res.json(err.errors)) 
    // },
    destroy: (req, res) => {
        pet.deleteOne({ _id: req.params.id })
            .then(data => res.json({ results: data }))
            .catch(err => res.json(err.errors))
    },
}