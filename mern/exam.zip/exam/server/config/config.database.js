const mongoose = require('mongoose')
const database = "PET";

mongoose.connect(`mongodb://localhost/${database}`, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}) 
    .then(res => console.log(`CONNECTED TO ${database} `))
    .catch(err => console.log(`FAILED TO CONNECT........${err}`))

