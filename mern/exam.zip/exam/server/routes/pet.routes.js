const petController = require('../controllers/pet.controller.js');


module.exports = (app) => {
    app.get("/api/pet", petController.index);
    app.post("/api/create/pet", petController.create);
    app.get("/api/pet/:id", petController.showOne);
    app.put("/api/update/pet/:id", petController.updateOne);
    app.delete("/api/destory/pet/:id", petController.destroy);     
}