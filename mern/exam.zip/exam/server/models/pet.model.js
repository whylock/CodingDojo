const mongoose = require('mongoose'); // Erase if already required
const uniqueVal = require('mongoose-unique-validator')

// Declare the Schema of the Mongo model
var PetSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "pet name is required"],
        minlength: [3, "name must be at least 3 characters"],
        unique: true,
        uniqueCaseInsensitive: true
    },
    type: {
        type: String,
        required: [true, "pet type is required"],
        minlength: [3, "type must be at least 3 characters"],
    },
    desc: {
        type: String,
        required: [true, "pet description is required"],
        minlength: [3, "description must be at least 5 characters"]
    },
    skillOne: {
        type: String,
        required: [true, "at least one skill is required"],
        minlength: [2, "skill must be at least 2 characters"]
    },
    skillTwo: {
        type: String,
    },
    skillThree: {
        type: String,
    },
    likes: {
        type: Number,
        default: 0
    }
}, { timestamps: true });

PetSchema.plugin(uniqueVal)
//Export the model
module.exports = mongoose.model('Pet', PetSchema);